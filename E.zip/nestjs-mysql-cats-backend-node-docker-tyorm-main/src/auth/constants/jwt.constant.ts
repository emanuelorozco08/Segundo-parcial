export const jwtConstants = {
  secret: 'no utilizar esta palabra en producción',
};
